Set of basic templates usable with TelosysTools ver 2.0.3 

( https://sites.google.com/site/telosystools/ )